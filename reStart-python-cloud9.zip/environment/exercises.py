print("Roxi")

print("Midnight call me up")

print(1,2,3,4,5,6)

print(64+32)

a=(64, 32)
print(sum(a, 0))

from datetime import date
today=date.today()
day=today.strftime("%d %m %Y")
print("today is ", day)

