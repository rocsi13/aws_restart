myMixedTypeList = [45, 123456789123456789123456789123456789123456789123456789123456789123456789, 1.02, True, "My dog is on the bed.", "45"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
